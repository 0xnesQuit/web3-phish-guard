"use strict";(()=>{function i(e,t){try{return chrome.i18n.getMessage(e,t)||e}catch{return e}}function w(e){return i(e.key,e.sub)}var E="w3pg-banner",A=8e3,o=null,s=null,g=()=>{try{return!chrome.runtime?.id}catch{return!0}};function L(e){s?.(),s=null,o?.remove();for(let n of Array.from(document.querySelectorAll("#"+E)))n.style.cssText="display:none !important",n.removeAttribute("id");let t=document.createElement("div");t.id=E,t.style.cssText="all:initial !important;position:fixed !important;right:16px !important;bottom:16px !important;z-index:2147483646 !important;display:block !important;max-width:min(420px, calc(100vw - 32px)) !important;",o=t;let a=t.attachShadow({mode:"closed"}),S=e.signals.filter(n=>n.weight>0).map(n=>`<li>${r(w(n))}</li>`).join("");a.innerHTML=`
    <style>
      :host{all:initial}
      .card{font:13px/1.45 system-ui,sans-serif;background:#2b1f00;color:#ffe6a8;border:1px solid #a97a1a;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.45);overflow:hidden}
      .head{display:flex;align-items:center;gap:10px;padding:10px 12px;cursor:pointer;user-select:none}
      .i{font-size:18px;line-height:1}
      .t{font-weight:700;flex:1;min-width:0}
      .score{flex:none;background:#f5a524;color:#1a1200;font-weight:800;font-size:12px;border-radius:999px;padding:2px 8px}
      .x{background:transparent;border:1px solid #a97a1a;color:#ffe6a8;border-radius:6px;padding:3px 8px;cursor:pointer;font:inherit;font-size:12px}
      .body{padding:0 12px 10px 40px}
      ul{margin:0 0 6px;padding-left:16px}
      li{margin:2px 0}
      .s{opacity:.8;font-size:12px}
      .card.min .body{display:none}
      .card.min .head{padding:6px 10px}
      .card.min .t{font-weight:600;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .card.min .x{display:none}
    </style>
    <div class="card" id="card" role="alert" aria-live="polite">
      <div class="head" id="head">
        <div class="i" aria-hidden="true">\u26A0\uFE0F</div>
        <div class="t">${r(i("overlay_short"))}</div>
        <div class="score" aria-label="${r(i("overlay_title",[String(e.score)]))}">${e.score}/100</div>
        <button class="x" id="close" aria-label="${r(i("overlay_close"))}">${r(i("overlay_close"))}</button>
      </div>
      <div class="body">
        <ul>${S}</ul>
        <div class="s">${r(i("overlay_hint"))}</div>
      </div>
    </div>`;let c=a.getElementById("card"),f=!1,l=!1,p=()=>{l||c.classList.add("min")},h=()=>c.classList.remove("min"),x=window.setTimeout(p,A),y=n=>{!n.isTrusted||!t.isConnected||(x!==void 0&&(clearTimeout(x),x=void 0),p())};window.addEventListener("pointerdown",y,{capture:!0,passive:!0}),window.addEventListener("keydown",y,{capture:!0,passive:!0}),c.addEventListener("mouseenter",h),c.addEventListener("mouseleave",()=>{l||p()}),a.getElementById("head").addEventListener("click",n=>{!n.isTrusted||n.target.id==="close"||(l=!l,l?h():p())}),a.getElementById("close").addEventListener("click",n=>{n.isTrusted&&(f=!0,u.disconnect(),t.remove(),o=null)});let b=()=>(document.documentElement||document.body).appendChild(t),u=new MutationObserver(()=>{if(g()){u.disconnect(),t.remove(),o=null;return}!f&&!t.isConnected&&b()});u.observe(document.documentElement,{childList:!0}),s=()=>{f=!0,u.disconnect()},b()}function r(e){return e.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}var d=()=>{s?.(),s=null,o?.remove(),o=null,m=-1};chrome.runtime.onMessage.addListener(e=>{e?.type==="w3pg:overlay"&&e.verdict&&(m=e.verdict.score,L(e.verdict)),e?.type==="w3pg:clear"&&d()});var m=-1,T=!1;function v(){if(g()){d();return}try{chrome.runtime.sendMessage({type:"w3pg:getVerdict"}).then(e=>{e&&e.band==="warn"&&e.score!==m?(m=e.score,L(e)):e&&e.band!=="warn"&&(T=!0,d())}).catch(()=>d())}catch{d()}}v();var H=0,M=()=>{T||g()||(document.visibilityState==="visible"&&v(),++H<24&&setTimeout(M,5e3))};setTimeout(M,5e3);document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&v()});})();
